let arvores = [];
let animais = [];

function setup() {
  createCanvas(800, 600);
  textSize(20);
}

function draw() {
  background(135, 206, 235); // Céu azul
  drawChao();

  // Atualiza e desenha as árvores
  for (let arvore of arvores) {
    arvore.crescer();
    arvore.mostrar();
  }

  // Aparece animal se há pelo menos 5 árvores crescidas
  if (arvores.length >= 5 && frameCount % 120 === 0) {
    animais.push(new Animal(random(width), height - 100));
  }

  // Mostra os animais
  for (let animal of animais) {
    animal.mover();
    animal.mostrar();
  }

  // HUD
  fill(0);
  text("Clique no chão para plantar árvores", 20, 30);
  text("Árvores: " + arvores.length, 20, 60);
}

function drawChao() {
  noStroke();
  fill(34, 139, 34);
  rect(0, height - 100, width, 100);
}

function mousePressed() {
  if (mouseY > height - 100) {
    arvores.push(new Arvore(mouseX, mouseY));
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.altura = 10;
  }

  crescer() {
    if (this.altura < 100) {
      this.altura += 0.2;
    }
  }

  mostrar() {
    stroke(139, 69, 19);
    strokeWeight(10);
    line(this.x, this.y, this.x, this.y - this.altura);
    noStroke();
    fill(34, 139, 34);
    ellipse(this.x, this.y - this.altura, 50, 50);
  }
}

class Animal {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vel = random(1, 2);
  }

  mover() {
    this.x += this.vel;
    if (this.x > width) {
      this.x = 0;
    }
  }

  mostrar() {
    fill(255, 165, 0);
    ellipse(this.x, this.y, 30, 20); // corpo
    ellipse(this.x + 10, this.y - 10, 15, 15); // cabeça
  }
}


